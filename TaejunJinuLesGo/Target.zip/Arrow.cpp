﻿#pragma once
#include "Game.h"

constexpr int MAX_ARROWS = 30;
constexpr int MAX_AMMO = 10;

constexpr float ARROW_SPEED = 1.0f;

constexpr int AMMO_HUD_X = 2;
constexpr int AMMO_HUD_Y = 1;

struct Arrow
{
    float x = 0.0f;
    float y = 0.0f;
    float prevX = 0.0f;
    float prevY = 0.0f;
    bool active = false;
};

extern Arrow arrows[MAX_ARROWS];
extern int ammo;

void SpawnArrow(int startX, int startY);
void DrawArrow(int x, int y, float dx, float dy, bool erase = false);
void DrawAmmoHUD();
void UpdateArrows();